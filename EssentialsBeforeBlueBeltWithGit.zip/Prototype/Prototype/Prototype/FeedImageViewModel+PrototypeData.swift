

import Foundation

extension FeedImageViewModel {
    static var prototypeFeed: [FeedImageViewModel] {
        return [
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "Spartacus"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "image-9"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "Spartacus"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "image-9"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "Spartacus"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "image-9"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "Spartacus"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "image-9"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "image-9"
        ),
        FeedImageViewModel(
            description: "This is Spartacus",
            location: "Spartacus",
            imageName: "Spartacus"
        )
        ]
    }
}
