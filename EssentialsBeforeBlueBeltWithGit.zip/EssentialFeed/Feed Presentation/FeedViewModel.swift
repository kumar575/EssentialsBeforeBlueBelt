



import Foundation

public struct FeedViewModel {
    public  let feed: [FeedImage]
}
