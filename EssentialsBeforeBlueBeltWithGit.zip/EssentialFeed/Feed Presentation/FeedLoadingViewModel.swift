



import Foundation

public struct FeedLoadingViewModel {
    public let isLoading: Bool
}
